package com.gs.springbootapp.dto;

import java.util.Date;

public class EmployeeDTO {

	private String firstName;
	private String lastName;
	private String event;
	private Date date;
	private String meetup;
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getMeetup() {
		return meetup;
	}
	public void setMeetup(String meetup) {
		this.meetup = meetup;
	}
	
}
