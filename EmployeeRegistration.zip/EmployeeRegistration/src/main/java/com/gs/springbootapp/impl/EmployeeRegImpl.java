package com.gs.springbootapp.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gs.springbootapp.dto.EmployeeDTO;
import com.gs.springbootapp.dto.Request;
import com.gs.springbootapp.helper.EmployeeRegHelper;
import com.gs.springbootapp.service.EmployeeRegService;

@Service
public class EmployeeRegImpl implements EmployeeRegService {

	@Override
	public List<EmployeeDTO> getEmployeeEventDetails(Request req) {
		List<EmployeeDTO> emplist = new ArrayList<>();
		List<EmployeeDTO> emp = EmployeeRegHelper.getEmployeeDetails(req);

		for (EmployeeDTO empObj : emp) {

			if (empObj.getFirstName().equals(req.getFirstName()) && empObj.getLastName().equals(empObj.getLastName())) {

				if (empObj.getDate().after(req.getStartDate()) && empObj.getDate().before(req.getEndDate())) {
					emplist.add(empObj);
				}

			}

		}

		return emplist;
	}

}
