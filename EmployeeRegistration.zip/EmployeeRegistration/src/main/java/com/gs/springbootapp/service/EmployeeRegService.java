package com.gs.springbootapp.service;

import java.util.List;

import com.gs.springbootapp.dto.EmployeeDTO;
import com.gs.springbootapp.dto.Request;

public interface EmployeeRegService {
	
	public List<EmployeeDTO> getEmployeeEventDetails(Request req);
}
