package com.gs.springbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeRegSpringBootApp {

	public static void main(String[] arg){
	SpringApplication.run(EmployeeRegSpringBootApp.class, arg);
	}
}
